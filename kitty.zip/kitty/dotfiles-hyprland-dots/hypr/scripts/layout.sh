hyprctl keyword general:gaps_in 0 &&
hyprctl keyword general:gaps_out 0 &&
hyprctl keyword decoration:rounding 0