hyprctl keyword general:gaps_in 5 &&
hyprctl keyword general:gaps_out 10 &&
hyprctl keyword decoration:rounding 10